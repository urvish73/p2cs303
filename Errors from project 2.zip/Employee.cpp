/*
Name: Nathaniel Barnett
cpp file for body functions of Employee class.
*/
#ifndef Library_CPP
#define LIbrary_CPP

#include "Employee.h"
using namespace std;

void Employee::set_retaining_time(book current_book, Date new_circ_date)
{
	retaining_time = new_circ_date - current_book.get_last_circ_date();
}

void Employee::set_waiting_time(Employee prev_owner)
{
	waiting_time = prev_owner.waiting_time + prev_owner.retaining_time;
}

bool Employee::operator>(Employee & E2)
{
	if ((waiting_time - retaining_time) > (E2.get_waiting_time() - E2.get_retaining_time()))
		return true;
	return false;
}

int Employee::emp_priority()
{
	return (waiting_time - retaining_time);
}

#endif